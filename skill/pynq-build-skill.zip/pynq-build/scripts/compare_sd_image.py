#!/usr/bin/env python3
"""Read-only image comparison; never mounts, repairs, or writes the target.

Ext4 field definitions: https://docs.kernel.org/filesystems/ext4/super.html
Exit 0: identical; 3: only expected mount-accounting bytes differ;
4: --details found only access-time metadata and internal journal changes;
1: other differences or invalid/unreadable input. Exits 3/4 are not exact matches.
"""
import argparse
import datetime
import json
import os
import stat
import struct
import subprocess
import sys

CHUNK = 4 * 1024 * 1024
FIELDS = {
    "mount_time": (44, 4),
    "write_time": (48, 4),
    "mount_count": (52, 2),
    "last_mounted_path": (136, 64),
    "kbytes_written": (376, 8),
    "write_time_hi": (628, 1),
    "mount_time_hi": (629, 1),
    "superblock_checksum": (1020, 4),
}


def read_exact(stream, length):
    parts = []
    while length:
        data = stream.read(length)
        if not data:
            raise ValueError("Unexpected end of image/device")
        parts.append(data)
        length -= len(data)
    return b"".join(parts)


def require_unmounted(path):
    if not stat.S_ISBLK(os.stat(path).st_mode):
        return  # Regular-file fixtures can also be compared.
    result = subprocess.run(
        ["lsblk", "--json", "--output", "NAME,MOUNTPOINTS", path],
        check=True, capture_output=True, text=True,
    )

    def check(nodes):
        for node in nodes:
            if any(node.get("mountpoints") or []):
                raise ValueError("Target or a partition is mounted; unmount first")
            check(node.get("children", []))

    check(json.loads(result.stdout)["blockdevices"])


def crc32c_raw(data):
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0x82F63B78 if crc & 1 else 0)
    return crc


def checksum_ok(sb):
    if not struct.unpack_from("<I", sb, 100)[0] & 0x400:
        return None  # metadata_csum absent.
    if sb[373] != 1:
        return False
    return crc32c_raw(sb[:1020]) == struct.unpack_from("<I", sb, 1020)[0]


def describe(sb):
    values = {}
    for label, (start, size) in FIELDS.items():
        data = sb[start:start + size]
        values[label] = (data.split(b"\0", 1)[0].decode("utf-8", "replace")
                         if label == "last_mounted_path" else int.from_bytes(data, "little"))
    for label in ("mount_time", "write_time"):
        seconds = values[label] + (values[label + "_hi"] << 32)
        try:
            values[label + "_utc"] = datetime.datetime.fromtimestamp(
                seconds, datetime.timezone.utc).isoformat()
        except (ValueError, OverflowError, OSError):
            values[label + "_utc"] = "out of range"
    values["state"] = struct.unpack_from("<H", sb, 58)[0]
    values["checksum_valid"] = checksum_ok(sb)
    return values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image")
    parser.add_argument("device")
    parser.add_argument("--details", action="store_true",
                        help="Map every difference to inode fields/journal; read-only")
    args = parser.parse_args()
    require_unmounted(args.device)
    size = os.stat(args.image).st_size
    with open(args.image, "rb", buffering=0) as reference, open(args.device, "rb", buffering=0) as target:
        mbr = read_exact(reference, 512)
        if mbr[510:512] != b"\x55\xaa":
            raise ValueError("Reference is not an MBR image")
        entry = mbr[462:478]  # Partition 2.
        start_lba, sectors = struct.unpack_from("<II", entry, 8)
        root_start = start_lba * 512
        sb_start = root_start + 1024
        if entry[4] != 0x83 or not sectors or root_start + sectors * 512 > size:
            raise ValueError("Unexpected root partition layout")
        superblocks = []
        for stream in (reference, target):
            stream.seek(sb_start)
            sb = read_exact(stream, 1024)
            if sb[56:58] != b"\x53\xef":
                raise ValueError("Missing ext4 superblock magic")
            superblocks.append(sb)
        expected, actual = superblocks
        detail_checker = None
        if args.details:
            from ext4_diff_details import Ext4Details
            detail_checker = Ext4Details(reference, target, root_start, expected)
        differences = [i for i, pair in enumerate(zip(expected, actual)) if pair[0] != pair[1]]
        allowed = {i for start, count in FIELDS.values() for i in range(start, start + count)}
        print(json.dumps({"image": args.image, "target": args.device,
                          "root_partition_offset": root_start,
                          "image_superblock": describe(expected),
                          "sd_superblock": describe(actual),
                          "changed_superblock_offsets": differences}, ensure_ascii=False, indent=2), flush=True)
        # Scan every byte outside the primary superblock too. No journal or
        # other metadata regions are silently exempted.
        bad_windows = 0
        examples = []
        scanned = 0
        for begin, end in ((0, sb_start), (sb_start + 1024, size)):
            reference.seek(begin)
            target.seek(begin)
            offset = begin
            while offset < end:
                count = min(CHUNK, end - offset)
                left, right = read_exact(reference, count), read_exact(target, count)
                if left != right:
                    for local in range(0, count, 4096):
                        a, b = left[local:local + 4096], right[local:local + 4096]
                        if a != b:
                            bad_windows += 1
                            if len(examples) < 256:
                                first = next(i for i, pair in enumerate(zip(a, b)) if pair[0] != pair[1])
                                examples.append(offset + local + first + 1)
                            if detail_checker is not None:
                                detail_checker.observe(offset + local, a, b)
                offset += count
                scanned += count
                if scanned // (512 * 1024 * 1024) != (scanned - count) // (512 * 1024 * 1024):
                    print(f"Scanned {scanned / 1e9:.2f}/{size / 1e9:.2f} GB", flush=True)
        details = detail_checker.summary() if detail_checker is not None else None
        target.seek(sb_start)
        if read_exact(target, 1024) != actual:
            raise ValueError("Superblock changed during scan; check automount or unstable reads")
        require_unmounted(args.device)
    print("Differing windows outside primary superblock:", bad_windows)
    print("First differing byte positions outside superblock (1-based):", examples)
    if details is not None:
        print("Detailed difference classification:")
        display = {key: value for key, value in details.items()
                   if key not in {"inodes", "inode_changes", "changed_journal_filesystem_blocks",
                                  "unknown_byte_examples"}}
        print(json.dumps(display, ensure_ascii=False, indent=2), flush=True)
        for record in details["inode_changes"]:
            fields = ("inode", "label_hint", "classification", "relative_offsets",
                      "checksums_valid", "stable_since_scan", "old_atime", "new_atime",
                      "unknown_offsets", "error")
            print("Inode:", json.dumps({key: record[key] for key in fields if key in record},
                                       ensure_ascii=False), flush=True)
    if bad_windows == 0 and not differences:
        print("IDENTICAL: all image-length bytes match.")
        return 0
    if (bad_windows == 0 and set(differences) <= allowed
            and checksum_ok(expected) is True and checksum_ok(actual) is True
            and struct.unpack_from("<H", actual, 58)[0] == 1):
        print("MOUNT_METADATA_ONLY: only listed mount-accounting fields/checksum differ; all remaining bytes match.")
        print("This is consistent with mounting/unmounting, not an exact bitwise match. Run e2fsck -fn on the unmounted root partition.")
        return 3
    if (details is not None and details["only_atime_and_journal_changes"]
            and set(differences) <= allowed
            and checksum_ok(expected) is True and checksum_ok(actual) is True
            and struct.unpack_from("<H", actual, 58)[0] == 1):
        print("ATIME_AND_JOURNAL_ONLY: outside the journal, only verified access-time fields and their checksums (plus listed superblock mount fields) differ.")
        print("All other image-length bytes match. This is consistent with mount/read activity, not a bitwise match or a validation of journal transactions.")
        print("If e2fsck -fn on the unmounted root partition also exits 0, this result supports proceeding to a board boot test.")
        return 4
    print("OTHER_DIFFERENCES: not explained solely by expected mount-accounting fields. Preserve output for diagnosis.")
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print("CHECK_FAILED:", error, file=sys.stderr)
        sys.exit(1)
