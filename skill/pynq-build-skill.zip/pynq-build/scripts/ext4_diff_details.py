"""Read-only attribution of image/SD differences for supported ext4 images.

Streams are supplied by the caller and are never written or closed here.
Journal attribution is descriptive: it does not validate journal transactions
or by itself prove that a difference is harmless.
"""
import bisect
import struct


def _u16(data, offset=0):
    return struct.unpack_from('<H', data, offset)[0]


def _u32(data, offset=0):
    return struct.unpack_from('<I', data, offset)[0]


def _crc32c(data, crc=0xffffffff):
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0x82f63b78 if crc & 1 else 0)
    return crc


class Ext4Details:
    """Use Ext4Details(reference, target, root_start, expected_sb).

    Call observe(absolute_offset, reference_bytes, target_bytes) for every
    differing window outside the primary superblock, then summary(). Both
    stream objects must support seek/read and be opened read-only.
    """
    # Inode numbers do not imply the same paths across different images.
    LABELS = {}

    def __init__(self, reference, target, root_start, expected_sb):
        self.reference, self.target, self.root = reference, target, root_start
        self.inodes, self.journal_blocks = {}, set()
        self.unknown_count, self.unknown_examples = 0, []
        self.total_differences, self.journal_bytes = 0, 0
        self.errors, self.tables, self.journal = [], [], []
        self.supported = False
        try:
            s = expected_sb
            if len(s) != 1024 or _u16(s, 56) != 0xef53:
                raise ValueError('Invalid ext4 superblock')
            log_block_size = _u32(s, 24)
            if log_block_size != 2:
                raise ValueError('Detailed attribution supports 4096-byte blocks only')
            self.bs = 1024 << log_block_size
            self.inode_size, self.ipg = _u16(s, 88), _u32(s, 40)
            self.first, bpg = _u32(s, 20), _u32(s, 32)
            self.blocks = _u32(s, 4) | (_u32(s, 336) << 32)
            self.inode_count = _u32(s, 0)
            incompat, rocompat = _u32(s, 96), _u32(s, 100)
            if (self.bs != 4096 or self.inode_size != 256 or _u16(s, 254) != 64
                    or _u32(s, 72) != 0 or not incompat & 0x80
                    or incompat & 0x10 or not rocompat & 0x400
                    or rocompat & 0x200 or not bpg or not self.ipg
                    or self.blocks <= self.first or self.root < 0
                    or s[373] != 1 or _crc32c(s[:1020]) != _u32(s, 1020)):
                raise ValueError('Unsupported ext4 geometry/features; attribution disabled')
            self.seed = (_u32(s, 624) if incompat & 0x2000
                         else _crc32c(s[104:120]))
            groups = (self.blocks - self.first + bpg - 1) // bpg
            if groups > 65536:
                raise ValueError('Unreasonable group count')
            table_length = self.ipg * self.inode_size
            for group in range(groups):
                d = self._read(reference, self.root + self.bs + group * 64, 64)
                table = _u32(d, 8) | (_u32(d, 40) << 32)
                start = self.root + table * self.bs
                if table == 0 or start + table_length > self.root + self.blocks * self.bs:
                    raise ValueError('Inode table lies outside filesystem')
                self.tables.append((start, start + table_length, group))
            self.tables.sort()
            if any(left[1] > right[0] for left, right in zip(self.tables, self.tables[1:])):
                raise ValueError('Overlapping inode tables')
            self.table_starts = [item[0] for item in self.tables]
            self.supported = True
            # A journal that cannot be mapped/checksummed is not exempted.
            try:
                journal_ino = _u32(s, 224)
                raw = self._read_inode(reference, journal_ino)
                if not self._inode_checksum(raw, journal_ino)['valid']:
                    raise ValueError('Reference journal inode checksum invalid')
                if not _u32(raw, 32) & 0x80000:
                    raise ValueError('Journal inode does not use extents')
                extents = self._extents(raw[40:100], set())
                size = _u32(raw, 4) | (_u32(raw, 108) << 32)
                logical_end = 0
                for logical, count, physical in sorted(extents):
                    if logical != logical_end:
                        raise ValueError('Journal extents have a hole/overlap')
                    logical_end += count
                    self.journal.append((physical, physical + count, logical))
                if logical_end * self.bs != size:
                    raise ValueError('Journal extents do not match journal size')
                self.journal.sort()
                if any(a[1] > b[0] for a, b in zip(self.journal, self.journal[1:])):
                    raise ValueError('Journal physical extents overlap')
            except (ValueError, OSError, struct.error) as error:
                self.journal = []
                self.errors.append(str(error))
        except (ValueError, OSError, struct.error) as error:
            self.supported = False
            self.errors.append(str(error))

    @staticmethod
    def _read(stream, offset, count):
        if offset < 0 or count < 0:
            raise ValueError('Invalid read boundary')
        stream.seek(offset)
        data = stream.read(count)
        if len(data) != count:
            raise ValueError('Short read while attributing ext4 differences')
        return data

    def _read_inode(self, stream, number):
        if not 1 <= number <= self.inode_count:
            raise ValueError('Inode number outside filesystem')
        group, index = divmod(number - 1, self.ipg)
        matches = [item for item in self.tables if item[2] == group]
        if len(matches) != 1:
            raise ValueError('Missing inode-table descriptor')
        return self._read(stream, matches[0][0] + index * self.inode_size, self.inode_size)

    def _extents(self, data, visited, expected_depth=None):
        if len(data) < 12 or _u16(data) != 0xf30a:
            raise ValueError('Invalid extent header')
        entries, maximum, depth = _u16(data, 2), _u16(data, 4), _u16(data, 6)
        if (depth > 5 or entries > maximum or maximum > (len(data) - 12) // 12
                or (expected_depth is not None and depth != expected_depth)):
            raise ValueError('Invalid extent depth/count')
        result = []
        for i in range(entries):
            pos = 12 + i * 12
            if depth:
                block = _u32(data, pos + 4) | (_u16(data, pos + 8) << 32)
                if not 0 < block < self.blocks or block in visited:
                    raise ValueError('Invalid/cyclic extent index')
                visited.add(block)
                result.extend(self._extents(self._read(self.reference,
                              self.root + block * self.bs, self.bs), visited, depth - 1))
            else:
                logical, count = _u32(data, pos), _u16(data, pos + 4)
                physical = (_u16(data, pos + 6) << 32) | _u32(data, pos + 8)
                if not 0 < count <= 32768 or not 0 < physical or physical + count > self.blocks:
                    raise ValueError('Invalid/unwritten journal extent')
                result.append((logical, count, physical))
        return result

    def _inode_checksum(self, raw, number):
        extra = _u16(raw, 128)
        if extra > self.inode_size - 128:
            raise ValueError('Invalid inode extra-isize')
        high = extra >= 4
        expected = _u16(raw, 124) | ((_u16(raw, 130) << 16) if high else 0)
        seed = _crc32c(struct.pack('<I', number), self.seed)
        seed = _crc32c(raw[100:104], seed)
        data = bytearray(raw)
        data[124:126] = b'\0\0'
        if high:
            data[130:132] = b'\0\0'
        calculated = _crc32c(data, seed)
        if not high:
            calculated &= 0xffff
        return {'valid': expected == calculated, 'stored': hex(expected),
                'calculated': hex(calculated)}

    def _unknown(self, absolute, old, new):
        self.unknown_count += 1
        if len(self.unknown_examples) < 16:
            self.unknown_examples.append({'image_byte_1based': absolute + 1,
                                          'old': old, 'new': new})

    def observe(self, absolute_offset, left_bytes, right_bytes):
        if absolute_offset < 0 or len(left_bytes) != len(right_bytes):
            raise ValueError('Invalid comparison window')
        for index, (old, new) in enumerate(zip(left_bytes, right_bytes)):
            if old == new:
                continue
            self.total_differences += 1
            absolute = absolute_offset + index
            if not self.supported:
                self._unknown(absolute, old, new)
                continue
            pos = bisect.bisect_right(self.table_starts, absolute) - 1
            if pos >= 0 and absolute < self.tables[pos][1]:
                start, _, group = self.tables[pos]
                offset = absolute - start
                number = group * self.ipg + offset // self.inode_size + 1
                self.inodes.setdefault(number, {})[offset % self.inode_size] = (old, new)
                continue
            block = (absolute - self.root) // self.bs
            if absolute >= self.root and any(a <= block < b for a, b, _ in self.journal):
                self.journal_blocks.add(block)
                self.journal_bytes += 1
                continue
            self._unknown(absolute, old, new)

    def summary(self):
        records, unknown = [], self.unknown_count
        unknown_examples = list(self.unknown_examples)
        for number, observed in sorted(self.inodes.items()):
            record = {'inode': number, 'ino': number, 'label_hint': self.LABELS.get(number),
                      'observed_offsets': sorted(observed),
                      'relative_offsets': sorted(observed), 'checksums_valid': False}
            try:
                before = self._read_inode(self.reference, number)
                after = self._read_inode(self.target, number)
                actual = {i: (a, b) for i, (a, b) in enumerate(zip(before, after)) if a != b}
                stable = actual == observed
                checksums = {'image': self._inode_checksum(before, number),
                             'target': self._inode_checksum(after, number)}
                allowed = set(range(8, 12)) | set(range(124, 126))
                if _u16(before, 128) >= 4 and _u16(after, 128) >= 4:
                    allowed |= set(range(130, 132))
                if _u16(before, 128) >= 16 and _u16(after, 128) >= 16:
                    allowed |= set(range(140, 144))
                bad = sorted(set(actual) - allowed)
                ea_inode = bool((_u32(before, 32) | _u32(after, 32)) & 0x200000)
                atime_changed = bool(set(actual) & (set(range(8, 12)) | set(range(140, 144))))
                valid = (stable and not bad and not ea_inode and atime_changed
                         and all(x['valid'] for x in checksums.values()))
                record.update(classification='ATIME_AND_CHECKSUM_ONLY' if valid else 'UNKNOWN_INODE_CHANGES',
                              stable_since_scan=stable, checksum=checksums, unknown_offsets=bad,
                              extended_attribute_inode=ea_inode, atime_changed=atime_changed,
                              old_atime={'seconds_low': _u32(before, 8),
                                         'extra': _u32(before, 140) if _u16(before, 128) >= 16 else None},
                              new_atime={'seconds_low': _u32(after, 8),
                                         'extra': _u32(after, 140) if _u16(after, 128) >= 16 else None},
                              checksums_valid=all(x['valid'] for x in checksums.values()),
                              changed_bytes=[{'offset': i, 'old': a, 'new': b}
                                             for i, (a, b) in sorted(actual.items())])
                if not valid:
                    unknown += max(1, len(actual))
                    for i, (a, b) in sorted(actual.items()):
                        if len(unknown_examples) >= 16:
                            break
                        unknown_examples.append({'inode': number, 'relative_offset': i,
                                                 'old': a, 'new': b})
            except (OSError, ValueError, struct.error) as error:
                record.update(classification='UNKNOWN_INODE_CHANGES', error=str(error))
                unknown += max(1, len(observed))
            records.append(record)
        return {'supported_layout': self.supported, 'errors': self.errors,
                'only_atime_and_journal_changes': bool(self.supported and not self.errors
                    and self.total_differences and unknown == 0
                    and all(x['classification'] == 'ATIME_AND_CHECKSUM_ONLY' for x in records)),
                'different_bytes_outside_primary_superblock': self.total_differences,
                'inode_changes': records, 'inodes': records,
                'journal_blocks': sorted(self.journal_blocks),
                'changed_journal_filesystem_blocks': sorted(self.journal_blocks),
                'changed_journal_bytes': self.journal_bytes,
                'journal_reference_extents': [{'start_block': a, 'end_block_exclusive': b,
                                               'logical_start': c} for a, b, c in self.journal],
                'unknown_byte_count': unknown, 'unknown_examples': unknown_examples,
                'unknown_byte_examples': unknown_examples,
                'journal_boundary': 'Attribution only; journal transactions are not validated. '
                                    'A journal location alone does not prove harmless changes.',
                'label_boundary': 'Paths are not inferred from inode numbers; resolve them against this specific reference image if needed.'}
