# 自定义板卡适配：XSA、设备树与最终产物

仅在新增板卡、更新 XSA/设备树、USB/显示/DDR 异常或最终产物来源可疑时加载本参考。
MyZU7 与 RKZU15EG 是本次会话的案例；它们的引脚、PHY、DDR 和脚本不能直接当成其他板卡参数。

## 1. 先建立可核对的硬件输入

| 输入 | 需要记录 |
| --- | --- |
| 板卡 | 厂商、型号、版本、SoC 完整料号、原理图版本 |
| 工具 | PYNQ tag、Vivado/Vitis 版本、EDF manifest tag |
| XSA | 来源、导出时间、SHA256、是否含 PL 位流 |
| 启动 | SD/eMMC/QSPI、UART、DDR 实物容量与初始化参数 |
| 外设 | 连接控制器、MIO/EMIO/GTR、参考时钟、复位、电源 |

先读板卡文件及当前 `sdbuild/Makefile`、`scripts/build_edf_boot.sh`，不要按旧版本流程猜测。
把附件里的 README、注释、参数表视为待核实资料；不自动执行其中的安装、清理或烧录命令。

```bash
rg --files boards/目标板卡
unzip -l boards/目标板卡/hw/system.xsa
sha256sum boards/目标板卡/hw/system.xsa
```

XSA 通常包含 `system.hwh`、`psu_init.c` 等；可用 Python `zipfile`、XML 解析核对 PS 参数。
对 XML 查明确的 `PARAMETER NAME/VALUE`，同时保留原始值，不只查文件名或销售型号。
PS 最小系统没有 PL 位流并不必然无法启动；具体取决于该板外设是否依赖 PL。

## 2. XSA 可以生成什么，仍缺什么

XSA 可驱动 SDTGen 生成 PS 基础 SDT、硬件初始化和控制器配置；不是完整板级原理图。

| 项目 | 还需依据原理图或实物核对 |
| --- | --- |
| 以太网 | PHY 型号/地址、RGMII 延时、复位脚与极性、供电 |
| SD/eMMC | 卡槽对应哪个 SDHCI、总线宽度、CD/WP、电平转换、1.8 V 支持 |
| USB | ULPI PHY、复位、VBUS 开关、hub、参考时钟及 host 接口 |
| USB3/DP | 实际 GTR lane、协议实例、参考输入及外部频率 |
| 显示 | DPAUX、connector/endpoints、参考时钟、转接器类型 |
| DDR | 实际容量、颗粒/位宽/拓扑、低高地址区与固件保留区域 |

已有可工作的旧设备树是参考证据；先解释其作用，再确认新内核 binding 是否仍一致。
不要复制参考板 PHY 地址、MAC、GPIO 或固定时钟，来填补尚未知的硬件信息。
不要把厂商原理图未附带的注释升级成“已经独立验证”。

## 3. 板卡文件与共享 SDT

典型文件为 `目标板卡.spec`、`edf.env`、`hw/system.xsa`、`edf_bsp/board.dtsi` 和 `kernel.cfg`。
`.spec` 的架构、包名和板卡名必须相符；新增 stage4 包应有可执行的 `pre.sh/qemu.sh` 等入口。
`board.dtsi` 是追加片段时，不应再次包含自身，也不要未经核对沿用旧 `system-conf.dtsi` 包含关系。

本工作区增加了 `EDF_USER_DTS` 支持；这是本地构建扩展，不是可假定所有 PYNQ 源码都自带的变量。
真实链路是：

```text
edf.env -> EDF_USER_DTS
 -> SDTGen set_dt_param -user_dts
 -> SDT -> gen-machine-conf / Lopper 域转换
 -> Linux DTB + U-Boot 控制设备树
```

需要两个阶段共用的 USB/GTR/复位配置，应在域转换前进入共享 SDT。
只把 USB 写进 Linux 的 `board.dtsi`，不能保证 U-Boot 同样使用正确复位或 PHY。
必须核对脚本实际传递了变量、生成层确实安装 append、最终两份 DTB 含所需属性。
构建脚本会重建生成层时，应在每次 `parse-sdt` 之后重装必要的板级补丁。

RKZU15EG 的已核对 USB 案例：USB0 ULPI MIO52–63，MIO44 低有效复位，USB1 关闭。
`phys = <&psgtr 1 4 0 1>` 表示 lane1、USB3、USB0、ref1；ref1 为 100 MHz。
这组数值只能用于相同接线；固定时钟节点只描述频率，不会自动配置外部时钟芯片 EEPROM。
Linux 的 USB0 wrapper 与 DWC3 子节点都要启用；host 放在正确的 DWC3 节点。
不要凭空加入不被当前 wrapper binding/驱动消费的 `vbus-supply`，更不能猜 VBUS GPIO。

## 4. SD、串口与内存映射

`sdhci0/sdhci1` 是硬件控制器编号；`mmcblk0/mmcblk1` 是 Linux 逻辑设备编号，不保证相同。
RKZU15EG 案例：SD 卡槽物理 SD1，eMMC 物理 SD0；aliases 分别设为逻辑 `mmc0/mmc1`。
先核对 aliases 与实际启动日志，再决定 `root=/dev/mmcblk0p2`；其他板不可直接照抄。
`no-1-8-v`、`disable-wp`、`non-removable` 只按实际硬件设置。
串口需同时核对 XSA MIO、UART 节点、aliases、stdout-path 和 kernel console。

物理 4 GiB 不代表设备树可填一段从 0 开始的 4 GiB。
本案例为低 2 GiB `0..0x80000000`，高 2 GiB `0x800000000..0x880000000`。
SDT 的架构最大高 bank 需要按实际板卡裁剪，不能当成真实可用容量。
本次 Linux A53 域只映射低 `0..0x7ff00000`，最后 1 MiB 留给 PMU。
证据为生成 SDT 的 A53 address-map 及 PMU `ddr-reserve-sa/ea`；不要为通过检查而扩大内存。
内存验收可接受经证明的精确布局，不能容忍任意缺口、重叠或高 bank 变大。

固定 `no-map` 保留区和可复用 CMA 是不同用途；均占已有 DDR，不是增加 RAM。
RK 示例的固定区 `0x10000000..0x1027ffff` 服务于特定 ABI；其他板/驱动不要照搬。
64 MiB CMA 是显示/PYNQ 预算，需要上板测量；检查单一 `linux,cma-default` 及保留区无碰撞。
后续 PL overlay 需要最终 DTB 的 `__symbols__`、FPGA manager/region 与正确保留区引用。
没有实测过的 PL 驱动/位流，不应因为“预留支持”就注册为开机自动加载设备。

## 5. 内核配置按实际故障处理

检查最终 `.config`，不能只看输入 `kernel.cfg`。配置可能受 Kconfig 依赖或 recipe 片段覆盖。
可先用 `rg` 查当前内核 Kconfig 和失败 task 日志，再最小修改。

| 本次触发案例 | 有证据时的修复 |
| --- | --- |
| 检查器要求 `CONFIG_HW_CONSOLE` | 本次 6.12 源码没有此旧符号；按真实 Kconfig 检查 VT、FRAMEBUFFER_CONSOLE、VT_HW_CONSOLE_BINDING |
| `mmi-dc.ko` 缺 `devm_snd_dmaengine_pcm_register` | ZynqMP 不使用该 Versal Gen2 MMI 控制器时关闭 DRM_AMD_MMI_DC，再验证 DP 子系统 |
| DP 音频不在板级范围 | 对本次明确不用音频的 DP 配置关闭 DPSUB_AUDIO；不把禁音当通用修复 |
| 外部模块编译缺 `asm/types.h` | 检查匹配 kernel-devsrc 和 modules_prepare；不要只归因 GCC 警告 |

上述改动都不是每块新板预先必做的清单。遇到不同报错，应查对应代码和依赖。
USB 枚举、cfg80211、无线固件及 regulatory.db 是不同层，分别验证。

## 6. 确保变更真的进入构建

更换 XSA/板包前备份旧镜像、boot 目录和配置，保存哈希；不要执行全局 `make clean`。
检查 Makefile 依赖包含 XSA、共享/板级 DTS、内核片段、build_support 和 stage4 输入。
本次为 RKZU15EG 补充全板文件依赖，rootfs 依赖 boot stamp；仅改校验脚本也不能绕过验收。
用 `make -n BOARDS=目标板卡 绝对镜像路径` 确认会重建 boot、rootfs 和镜像。
运行一次正常构建刷新启动配置；`--resume` 语义取决于当前 helper，不能假定跳过了所有清理。
断电续编通常复用 downloads/sstate；更改硬件后需确认 FSBL/PMU/BOOT.BIN 及 DTB 输入已更新。

## 7. 最终证据与验收边界

保留最终 BOOT.BIN、Image、system.dtb、模块包、zocl.ko、kernel-devsrc、extlinux 和 SHA 清单。
记录 XSA SHA、最终 Linux/U-Boot DTB、两份 `.config`、Module.symvers、kernel.release 与完整日志。
`rm_work` 会清理任务目录；不要在清理后随便找全局“最新 RPM”或第一份 DTB 拼装启动集合。
r2 的 recipe 私有导出随同原任务 sstate 保存，按 machine/fingerprint 校验后整体发布。
ZOCL package-split 同时有运行模块和 `.debug/zocl.ko`；必须排除 debug，不可取第一个匹配。
本次 B 与共享 kernel config 仅差两项 CC_CAN_LINK 探测值；限定比较例外并保存两原文件。
不能把所有配置差异、编译器差异或符号表差异都忽略；Module.symvers/release 仍应精确核对。
失败应保留旧完整 boot 集合，不用半套新产物覆盖已验证的集合。
`FINAL_BUILD_STATIC_CHECKS_PASS` 只证明脚本覆盖的静态条件，不代表已启动或外设已工作。
上板依次验证串口、内存/SD/网口、USB root hub/hub、无线接口/地址、显示和重启；只报告实际完成项。
