# 自定义板卡构建与中断恢复

适用于本工作区的 PYNQ 4.0 EDF 路线：Vivado/Vitis 2025.2、EDF `amd-edf-rel-v25.11.1`、Ubuntu Noble aarch64 基底。它包含本地构建修正；新克隆的上游仓库须先检查脚本和补丁，不能假定行为相同。

## 1. 先冻结输入，再选择命令

先读实际 `sdbuild/Makefile`、`scripts/build_edf_boot.sh`、板卡 `.spec` / `edf.env` 与正在使用的主机 wrapper。核对：

- PYNQ tag、commit、未提交修改；EDF manifest tag 和已同步的各层 revision。
- Vivado/Vitis 实际版本、XSA 器件/导出版本及 SHA256；不能只看文件名。
- 主机仓库路径、容器挂载路径、Docker 镜像、board 名称、boot/Linux machine。
- 是否复用官方 rootfs/sdist，是否已有经过验证的镜像要保存。
- 板包是否有额外安装器、hooks、指纹或最终产物验证；不要绕过这些步骤。

```bash
# Linux 主机；这两个值是本机位置与待选择板名，不是所有项目的默认值。
export PYNQ_ROOT=/mnt/data/PYNQ
export BOARD_NAME=MyBoard
git -C "$PYNQ_ROOT" describe --tags --always
git -C "$PYNQ_ROOT" rev-parse HEAD
git -C "$PYNQ_ROOT" status --short
sha256sum "$PYNQ_ROOT/boards/$BOARD_NAME/hw/system.xsa"
```

将上述信息和命令写入本次检查记录。已有 `.repo` 时，脚本不会因为改了 `EDF_MANIFEST_TAG` 就自动重新 `repo init`；同时核对实际 manifest。`repo sync` 也可能联网，不属于 BitBake fetch 缓存保证。

## 2. 板卡最小配置与硬件边界

ZynqMP custom 板名示例为 `MyBoard`，相应 machine 示例为 `zynqmp-myboard-pynq`；其他 SoC 必须重新核对支持流程。

```make
# boards/MyBoard/MyBoard.spec
ARCH_MyBoard := aarch64
FPGA_MANAGER_MyBoard := 1
STAGE4_PACKAGES_MyBoard := xrt pynq ethernet
```

```bash
# boards/MyBoard/edf.env；路径相对本板目录。
EDF_MANIFEST_TAG=amd-edf-rel-v25.11.1
EDF_MODE=custom
EDF_BOOT_MACHINE=zynqmp-myboard-pynq
EDF_LINUX_MACHINE=zynqmp-myboard-pynq
BSP_XSA_PATH=hw/system.xsa
```

`edf_bsp/board.dtsi`、`kernel.cfg`、可选 U-Boot 配置来自真实接线和功能要求。核对 DDR、串口、SD/eMMC 编号、网口 PHY、复位与时钟。XSA 不能完整推断外部 PHY 型号/地址或板级供电；旧设备树片段也不代表新完整配置。

不要把 RKZU15EG 的 DP、USB GTR、固定暂存内存或 CMA 数值复制为其他板卡的默认要求。PS 基础镜像可不带 PL bitstream；这不证明任何未来 overlay 与当前 PS 时钟/地址兼容。

本地脚本支持 `EDF_USER_DTS`，在 SDTGen `generate_sdt` 前传入 `-user_dts`，适合必须同时进入 Linux/U-Boot 的共享配置。先确认目标仓库确实消费此变量；仅在 `edf.env` 写变量不会自动生效。

## 3. 备份与路径

开始重建前，把重要镜像、boot 集合、板目录、XSA、最终配置/符号表和日志保存到仓库外或独立 `backups/`。备份后比较 SHA256，记录文件大小；同盘备份主要防构建覆盖，不代替异盘备份。

本地 `make clean` 会递归删除 `sdbuild/build` 和 `sdbuild/output`。把旧镜像改名留在 output 里，仍会被 clean 删除。也不要把备份板包放进 `boards/*/*.spec` 扫描范围。

| 主机 | 容器内 | 用途 |
|---|---|---|
| `$PYNQ_ROOT` | `/workspace` | 挂载同一仓库 |
| `sdbuild/prebuilt` | `/workspace/sdbuild/prebuilt` | rootfs / sdist / 工具链源码包 |
| `sdbuild/edf-cache` | `/workspace/sdbuild/edf-cache` | EDF 层、downloads、sstate |
| `/tools/Xilinx/2025.2` | 同一路径，只读挂载 | AMD 工具 |

不要在容器命令里误用主机 `/mnt/data/PYNQ`。BitBake 使用容器普通构建用户；容器拥有挂载权限不等于应把全部构建改为 root。

## 4. 复用预构建软件基底

本地 Makefile 默认读取：

```text
sdbuild/prebuilt/pynq_sdist.tar.gz
sdbuild/prebuilt/pynq_rootfs.aarch64.tar.gz
```

本案例对应 AMD 官方 `pynq-v4.0.0.tar.gz` 与 `noble.aarch64.4.0.0.tar.gz`。已有完整包先验证 gzip 和已记录 SHA256；需要下载时从对应版本官方来源取得。它们不包含新板的全部 EDF 缓存及专用启动文件。

复用时使用 `env -u REBUILD_PYNQ_SDIST -u REBUILD_PYNQ_ROOTFS`。本 Makefile 使用 `ifdef`，写成 `REBUILD_PYNQ_ROOTFS=0` 仍会选中重建分支。

只有任务确实要求重建通用软件基底时才使用下面已存在的开关；它会增加 Ubuntu、pip 和 MicroBlaze 工具链工作：

```bash
# 容器内，根据实际需求分别开启；不是每次换板都要执行。
make BOARDS="$BOARD_NAME" REBUILD_PYNQ_SDIST=1 REBUILD_PYNQ_ROOTFS=1
```

## 5. 主机启动容器，容器内执行 make

优先复用已核对的板级 wrapper。若手动启动，下例针对已存在的 `pynqdock:4.0` 和许可证目录；实际许可证文件/服务器形式须调整对应参数，不能盲挂载或改写。

```bash
# Linux 主机，先设置真实工具与许可证目录。
export XILINX_TOOLS=/tools/Xilinx/2025.2
export XILINXD_LICENSE_FILE="$HOME/.Xilinx"
docker run -it --init --rm \
  --hostname "$(hostname)" --network host --privileged \
  -e BOARD_NAME -e XILINX_TOOLS -e XILINXD_LICENSE_FILE \
  -e BB_NUMBER_THREADS=4 -e PARALLEL_MAKE_JOBS=4 \
  -v "$XILINX_TOOLS:$XILINX_TOOLS:ro" \
  -v "$XILINXD_LICENSE_FILE:$XILINXD_LICENSE_FILE" \
  -v "$PYNQ_ROOT:/workspace" pynqdock:4.0 /bin/bash
```

`docker.sock permission denied` 发生在进入编译之前。先核对 Docker 可用性；本机 wrapper 已支持普通 docker 失败后使用 `sudo docker`。不要通过开放 socket 为全员可写来修复，也不要为了该错误修改工具许可证。

```bash
# 容器内；entrypoint 按 XILINX_TOOLS 加载工具环境。
cd /workspace/sdbuild
vivado -version
vitis -version
set -o pipefail
env -u REBUILD_PYNQ_SDIST -u REBUILD_PYNQ_ROOTFS \
  make BOARDS="$BOARD_NAME" 2>&1 | tee -a "$BOARD_NAME-build.log"
```

`BOARDS=` 控制构建板；默认可能发现多个板。`BB_NUMBER_THREADS` 和 `PARALLEL_MAKE_JOBS` 在本地 EDF 脚本中有效，优先按内存调小，不能假定外层 `make -j` 等同于 BitBake 并行配置。

流程依次生成共享 SDT/custom machine，构建 bootbin/kernel/ZOCL/devsrc，再安装板级 rootfs 软件并组装镜像。不要在同一 custom EDF 工作目录同时生成不同板的 machine 层；并行任务应使用独立工作目录。

## 6. 先定位真实错误

记录本次日志起点，避免把追加日志里旧失败当新失败。保留首条具体错误、失败任务与上下文；`make: ... Error 1`、ERROR 数量、WARNING 数量都不是根因。

```bash
rg -n 'ERROR:|fatal error:|FATAL ERROR|undefined!|Exec format error|Task .*failed|log.do_' \
  /workspace/sdbuild/"$BOARD_NAME-build.log"
```

按行号读相邻上下文，再打开对应 `temp/log.do_*`。下载看 URL/SRCREV，编译看首个 C/链接/modpost 错误，设备树看实际预处理输入，归档看当前 recipe 的文件来源。日志可含敏感环境，分享时只取相关片段。

`Loading cache`、`Parsing recipes` 常是正常阶段。`Runqueue deadlocked on deferred tasks` 若随后被调度器解除且所有任务成功，不单独判失败；若长期无进展再查任务状态和最终退出码。

## 7. 断电或失败后恢复

先确认旧容器/进程没有继续运行，检查磁盘空间。用 `findmnt -R` 查看本板 staging 的残留 bind mount；确认无其他任务使用后只卸载实际挂载项。挂着主机 dev/proc/run/sys 时，不能递归删除 staging。

输入未变时复用同一路径、Docker 镜像、下载和 sstate，重跑构建即可；未完成任务可能重做，已完成任务尽量复用。不要默认执行 `make clean`、删除 EDF `tmp` 或换 machine 名称。

普通 EDF 流程可用下列环境变量跳过脚本主动清理 boot 配方；它不是 BitBake 的全局断点恢复开关：

```bash
# 容器内，且已核对未改变 XSA/板级配置。
env -u REBUILD_PYNQ_SDIST -u REBUILD_PYNQ_ROOTFS \
  EDF_NO_CLEAN=1 make BOARDS="$BOARD_NAME"
```

本机旧 RK wrapper 接收 `--resume`；foundation-r2 的 `build-foundation-r2.sh` 不接收参数，其 `rk_hooks.sh` 会覆盖 `step_build` 并主动刷新指定 boot 配方。因此先读当前 wrapper/hooks，不能承诺所有 `--resume` 都跳过清理。

改变 XSA/设备树/内核片段或包装脚本后按新输入正常构建，并检查顶层 `.boot_built` 与 Make 依赖。本地 Makefile已跟踪常见板输入，RK 指纹还覆盖整板目录；迁移到旧仓库时须重新验证。必要时先备份移走本板标记及受影响阶段产物，不能只改时间戳后声称全链已更新。

### ARM64 chroot 与 LD_PRELOAD

重启后 `chroot ... bash: Exec format error` 通常先查 x86 主机的 ARM64 binfmt 注册、QEMU 是否存在、目标 ELF 架构。确认该问题后可在主机注册并重试：

```bash
sudo docker run --privileged --rm tonistiigi/binfmt --install arm64
```

QEMU 的 `-version` 检查通过不代表 binfmt 能运行 ARM64 程序。已有 staging 可用只读挂载测试 `chroot ... /usr/bin/true`，先证明架构执行可用再重跑耗时 EDF。

直接 root/chroot 预检可能继承 Dockerfile 的 x86 `LD_PRELOAD`，导致 ARM 动态链接器报告 libudev/libcap 路径找不到且 `ignored`。本机预检单独添加 `docker run -e LD_PRELOAD=`；不要因此改目标库软链或全局关闭主构建所需环境。

### AppArmor / user namespace 与 mconf

先看到 `User namespaces are not usable by BitBake`，随后 `mconf`/`kconfig-frontends-native` 缺失时，先解决前置 namespace 错误。缺 mconf 可能只是连锁结果，不应先替换系统工具。

本案例使用下列临时主机设置；先记录原值，只在确认同类限制并获任务授权后调整，结束恢复实际原值，不写永久 sysctl 配置：

```bash
sysctl kernel.apparmor_restrict_unprivileged_userns
sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0
```

若 namespace 修复后 mconf 仍单独失败，再查 native recipe 的具体日志。不要把所有 Ubuntu/Docker 错误都套用此开关。

## 8. 下载缓存必须按层区分

| 层 | 本地位置/机制 | 不能替代 |
|---|---|---|
| EDF 源码 | `edf-cache/downloads`，BitBake `DL_DIR` | apt、pip、ct-ng |
| EDF 已构建任务 | `edf-cache/sstate`，`SSTATE_DIR` | 源码或新板配置 |
| 工具链源码 | `prebuilt/toolchain-sources`，ct-ng tarball cache | BitBake downloads |
| rootfs / sdist | `prebuilt/*.tar.gz` | 专用 BOOT.BIN / DTB |
| rootfs 包 / Python | chroot apt、pip / Git 下载 | EDF fetch 离线检查 |

EDF workspace 和本板 machine 初始化后，先读实际环境初始化脚本并进入正确 build 目录。在普通 BitBake 构建用户下，按本次真实 machine 分别预取：

```bash
MACHINE="${BOOT_MACHINE:?verified boot machine}" bitbake xilinx-bootbin --runall=fetch
MACHINE="${LINUX_MACHINE:?verified Linux machine}" bitbake virtual/kernel zocl kernel-devsrc --runall=fetch
```

本机已有以下辅助脚本可复用；它是本机教程的产物，不假定其他克隆包含该路径：

```bash
bash /workspace/outputs/pynq4-board-porting-tutorial/support/prefetch-edf-board.sh \
  "$BOARD_NAME" /workspace
bash /workspace/outputs/pynq4-board-porting-tutorial/support/prefetch-edf-board.sh \
  "$BOARD_NAME" /workspace --offline-check
```

它按 boot/Linux machine 分别对 `xilinx-bootbin`、`virtual/kernel`、`zocl`、`kernel-devsrc` 执行 `--runall=fetch`；离线检查用临时 `BB_NO_NETWORK=1`。仅证明这组 fetch 可离线，不证明完整构建无需网络，也不保证板级 hooks 在离线环境可运行。

ct-ng 的 `libiconv`/`ncurses download failed` 应查 `sdbuild/build/gcc-mb/build.log` 的准确版本和 URL。本地 `packages/gcc-mb/build.sh` 支持 `TOOLCHAIN_SOURCE_CACHE`，默认持久缓存到 `prebuilt/toolchain-sources`；预放源码必须核对版本/校验值。提高文件句柄或重试 EDF fetch 不能补齐该缓存。

PYNQ rootfs 安装还会递归克隆 `embeddedsw`。本地 `packages/pynq/pre.sh` 优先复用构建 checkout 中精确 gitlink commit，通过单次 Git `url.*.insteadOf` 和 `protocol.file.allow` 从本地克隆。验证目标子模块 HEAD、对象完整且无外部 alternates 依赖；不能省略 setup.py 所需源码。

TLS/连接失败保留缓存，按确切 SRCREV 补齐或换可验证镜像；不使用 `sslVerify=false`、`--no-check-certificate`。只在确认远程 sstate `.siginfo` 故障时，备份该工作区 `local.conf` 后禁用远程 `SSTATE_MIRRORS`，保留本地缓存；不把它当通用下载修复。

## 9. 构建完成仍要核验最终材料

检查 make/BitBake 实际退出成功、新镜像与本板 boot 集合、最终 Linux/U-Boot DTB、内核 `.config`、`Module.symvers`、release、模块来源和校验清单。启用了 `rm_work` 时，尽量在 recipe 的正确任务阶段归档，不从全局目录随便选最新 RPM。

记录产物大小和 SHA256，再做 SD 写卡校验及上板启动。静态验证、编译成功和上板 USB/显示/Wi-Fi 实测是不同证据；不要把一次成功构建写成新硬件功能已验证。
