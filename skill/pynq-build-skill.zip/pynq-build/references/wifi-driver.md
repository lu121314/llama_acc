# AIC8800 无线驱动：匹配内核、安装与联网

用于 PYNQ 自定义板卡的 USB 无线网卡排查。先确认目标板、当前镜像和 USB ID，再选源码与流程。
这里的 AIC8800DC 案例不能推广为所有 AIC8800 芯片、所有 ARM64 系统的通用安装包。
厂商发行版名称、商品名和 PYNQ 版本都不能代替实际内核及芯片证据。
官方现成镜像是特定板卡的完整系统；它不等于任意自定义板卡的 BSP、离线源码包或匹配驱动。

## 1. 先取得证据

在板卡串口或已有有线 SSH 中执行，不在编译电脑上执行安装器：

```bash
uname -m
uname -r
lsusb
lsmod | grep aic
iw dev
ip -br link
sudo dmesg | tail -n 100
```

- 没有 USB root hub：先查 USB 主机模式、设备树、时钟、复位、供电和内核配置。
- 有 hub、没有网卡：查接口、供电、线缆和枚举日志；安装 Wi-Fi 模块不能修复未枚举设备。
- 本次网卡 `a69c:5721 Aic MSC` 是存储模式；模式切换后为 `a69c:88dc AIC8800DC`。
- `lsmod` 无 AIC、`iw dev` 无接口：还没有证明驱动安装或加载成功。
- `wlan0 DOWN` 只表示接口未启用；扫描到 SSID 也不等于已认证、取得 IP 或能上网。

## 2. 模块必须匹配运行中的内核

核对 AArch64 架构、精确 `uname -r`、有效内核配置、最终 `Module.symvers`、源码版本和构建来源。
再查 `file module.ko`、`modinfo -F vermagic module.ko`、MODPOST 与符号解析结果。
`vermagic` 还包含 SMP、preemption、module unload、MODVERSIONS 等特征，不能只比较版本前缀。
同为 `6.12.40-xilinx-g0900176227cc` 的 MyZU7、RKZU15EG USB-host、foundation-r2 模块也不能互换。
PYNQ 3.0.1 板卡必须按其实际内核重新核对；不能直接沿用 PYNQ 4.0 的 `.ko`。
`CONFIG_MODVERSIONS=y` 时检查导入符号 CRC；关闭时没有 CRC 证据，版本相同仍不能证明 ABI。
若使用的 ABI 检查器报告缺少符号 CRC，只能视为证据不足；按该检查器文档解释，不能把未知状态当作通过。
应以精确来源、配置及符号表对应的新构建补证；不改 vermagic，不使用 force 加载。
模块签名政策、固件匹配及运行时 USB/Wi-Fi 行为还需分别验证。

本工作区历史包仅作来源案例，选用前重新核对文件和 BUILD-INFO：

| 包目录（位于 `/mnt/data/PYNQ/outputs/`） | 用途与证据边界 |
| --- | --- |
| `aic8800-pynq4` | 最早 MyZU7 内核构建；不是 RKZU15EG 的默认包 |
| `aic8800-rkzu15eg-usbhost` | 2026-10-14 USB-host 镜像对应重编；对话已证实加载、枚举和扫描 |
| `aic8800-rkzu15eg-foundation-r2` | 2026-10-19 DP/PL 镜像对应重编；编译/静态检查通过，尚无该包板端运行证据 |

foundation-r2 案例镜像 SHA256 为 `eee323b245bf017497bf81ad0f75d4bf3bf78cb2d2363debe153fe6bd684771e`。
其 Module.symvers SHA256 为 `99cb732ff557462f342f26b641bce892da7fd3fac9b062818479d8fb51d4c5b3`。
旧 USB-host 表哈希为 `39f62c10b9307c72fdb4cc21a4c69b32f81af9ea3b72145a24ef58cdf122eae5`，两者不同。
这些常量标识历史构建，不能写成所有后续编译必须满足的默认值。

## 3. 从匹配开发树重编

优先保存最终构建的 kernel-devsrc、`.config`、`Module.symvers`、kernel.release 和工具链来源。
本案例开发树来自 `sdbuild/build/noble.RKZU15EG/usr/lib/modules/<release>/build`，不是普通发行版 headers。
先复制到独立 work 目录再准备，保持最终证据和原树不变；开发树软链接必须解析到真实匹配内容。
`fatal error: asm/types.h: No such file or directory` 通常指向缺少 ARM64 generated headers 或开发树未准备。
在匹配树、正确 ARCH/工具链下运行 `modules_prepare`，检查 `arch/arm64/include/generated/uapi/asm/types.h`。
不能把宿主 x86 headers、`/usr/include/asm` 或任意其他内核 headers 链接进去“修好”编译。
`modules_prepare` 不会生成完整构建的 Module.symvers；必须保留真正匹配的最终符号表。
原失败日志 GCC 13.4 对 GCC 13.2 的提示是警告；当次致命错误是缺少 `asm/types.h`。
工具链仍尽量与内核一致，不能据此把所有编译器差异都当成安全。

本机已有可复查来源：

- 原厂 DEB：`work/aic8800-port/source/aic8800_linux_driver_2024_0510/aic8800fdrvpackage_2024_0510.deb`。
- DEB SHA256：`b99eefd9332f81e2b88ba5599a8943e8702b690f1c013437203b9d5ec3f4906d`。
- Linux 6.12 补丁：`outputs/aic8800-rkzu15eg-foundation-r2/linux-6.12.patch`。
- 对应独立构建及日志：`work/aic8800-rkzu15eg-foundation-r2/`。

用 `dpkg-deb -x` 解包到新的目录，不在主机执行 DEB 的 postinst。
检查源码版本后应用补丁；补丁修改 cfg80211/wiphy 锁、通知参数、beacon/AP 更新与 radar API。
这是针对现有原厂版本的兼容修改，不是任意新源码可直接套用的补丁。
补丁必须无意外 fuzz/offset；失败时停止并比较源码，禁止叠加重复补丁。
生成的目标包括 `aic_load_fw.ko`、`aic8800_fdrv.ko`，同时保留匹配 `firmware/aic8800DC`。

仅作交叉编译结构示例，变量须先核实为本次目标的绝对路径和精确版本：

```bash
make -C "${KDIR:?prepared matching kernel tree}" ARCH=arm64 \
  CROSS_COMPILE="${CROSS_PREFIX:?matching toolchain prefix}" \
  KERNELRELEASE="${TARGET_RELEASE:?exact target release}" modules_prepare
make -C "$KDIR" ARCH=arm64 CROSS_COMPILE="$CROSS_PREFIX" \
  KERNELRELEASE="$TARGET_RELEASE" M="${DRIVER_DIR:?vendor driver directory}" -j4 modules
```

保留准备前后配置并逐项审查差异；本案例只有编译器名称及两个链接能力探测项差异有解释。
不要广泛忽略 CONFIG 项，不用 `olddefconfig` 静默改变目标功能后再声称“配置相同”。
本机 `work/aic8800-port/hosttools/{bison,flex,m4}` 包装器依赖 EDF native 工具和 uninative loader 的绝对路径。
它们只适用当前已核实缓存；迁移机器应安装宿主构建工具或重新定位，不能当可移植二进制发布。
保存源包/补丁/配置/符号表/模块哈希、编译日志、完整 vermagic 和运行验证状态。

## 4. 板端安装与模式切换

仅在对应镜像和包已核对后使用安装器。以下是 foundation-r2 的历史命令例子：

```bash
cd /home/xilinx
tar -xzf aic8800-rkzu15eg-foundation-r2-6.12.40.tar.gz
cd aic8800-rkzu15eg-foundation-r2
sha256sum -c SHA256SUMS
sudo bash install.sh
```

先审阅安装器：修改前应检查 aarch64、精确 release、模块 vermagic、目标 Module.symvers 哈希和包完整性。
基础配置的精确对应依赖构建证据；当前安装器没有逐项比较板端 `.config`，不能夸大其检查范围。
缺开发材料或哈希不符时停止并找正确镜像/重编，不删除检查来绕过。
安装器备份旧模块、固件和配置到 `/var/backups/aic8800-pynq4/时间戳-PID/`；备份不等于自动回滚。
随后安装到 `/lib/modules/<release>/updates/aic8800`、`/lib/firmware/aic8800DC`，更新 udev 与自动加载配置。
执行 `depmod -a <release>`、重载 udev 规则、加载 `aic8800_fdrv`；失败应保留终端输出和备份。
不要在 QEMU/chroot 跑板端安装器：`uname` 反映宿主内核，也不代表目标硬件已经能加载模块。
把“包预放在 /opt”与“已安装、模块加载、USB 切换、关联联网”作为独立验证阶段。

安装后物理拔插网卡，再执行第 1 节检查；预期看到 `88dc`、两个 AIC 模块和无线接口。
udev 规则针对 `a69c:5721` 的 sd 设备创建 `/dev/aicudisk` 并调用 `eject`，不是格式化设备。
仍为 5721 时检查 `command -v eject`、规则文件、`ls -l /dev/aicudisk` 和 udev 属性。
只有确认目标 VID/PID 的确对应该网卡后才考虑手动 `eject /dev/aicudisk`；不能猜 `/dev/sda`。
固件加载失败应查路径、芯片 DC 变体与 dmesg，不混入不同 AIC 芯片固件试错。

## 5. 连接热点并保留有线调试

先查 `systemctl is-active NetworkManager systemd-networkd networking`、interfaces 与现有 supplicant。
已由 NetworkManager 管理时使用其流程，例如 `sudo nmcli --ask device wifi connect '实际SSID'`。
没有 NetworkManager 时不能照抄 nmcli；不要同时启动独立 supplicant、ifupdown 和 networkd 管同一接口。
本案例 ifupdown 已配置 eth0 DHCP 与 eth0:1 静态 `192.168.2.99/24`，保留它们，不覆盖全局 interfaces。
无线使用独立 wlan0 stanza：`allow-hotplug wlan0`、`iface wlan0 inet dhcp`、`wpa-conf` 指向权限 600 的凭据文件。
只重配 wlan0，不重启全局 networking；无线 SSH 会断开，操作前改用串口或有线。
先试 2.4 GHz、WPA2 Personal 热点；本案例改成 2.4 GHz 后已能扫描，不能据此保证所有频段支持。
`eduroam` 等企业认证、开放网络、WPA3-only 需要独立配置，普通 PSK 流程不适用。

密码仅在板端隐藏输入，经 stdin 交给 `wpa_passphrase`，删除其输出中的明文 `#psk=` 注释。
不要将密码放命令参数、聊天、截图、shell history、`set -x` 或 tee 日志；派生 PSK 本身也是凭据。
可用 `sed '/^[[:space:]]*#psk=/d'` 过滤注释，但仍须正确转义 SSID、清理临时文件和设权限。
已有 `outputs/rkzu15eg-wifi-guide/connect-wifi.sh` 可交互隐藏输入，先读 `--help`、版本限制及管理器检测。
该 helper 绑定 wlan0/ARM64/精确内核、WPA/WPA2 个人网络与 8–63 可打印 ASCII 口令，不是通用管理器。
在兼容条件核实后使用既有 helper；遇到多行粘贴损坏先修复输入，避免每次临时编写复杂联网脚本。
已有 `wifi-status.sh` 用于只读状态采集；公开报告前隐藏 SSID、MAC、IP 等信息，不发送凭据文件。

```bash
sudo ip link set wlan0 up
sudo iw dev wlan0 scan | grep SSID
sudo bash connect-wifi.sh
iw dev wlan0 link
ip -4 -br addr show wlan0
ip route
resolvectl status wlan0
```

helper 使用 DHCP metric 600，通常让更低 metric 的有线路由优先；检查实际路由，不声称 Wi-Fi 已成为出口。
关联成功但无 IPv4 查 DHCP；有 IP 无外网依次查实际网关、路由、DNS及热点共享状态。
最终分别验证无线联网、有线访问 PYNQ/Jupyter、拔插恢复和重启后连接；只有获得板端输出才能标记通过。
