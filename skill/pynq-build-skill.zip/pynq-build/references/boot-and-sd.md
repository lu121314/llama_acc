# SD 烧录、启动与读回差异

默认给用户直接的 `dd`、`cmp` 命令。只在出现真实差异或 I/O 错误时进入深入检查。
用户已明确要求重刷且目标可核实时，不追加不必要的确认流程或强制使用封装 helper。
没有 sudo 密码或设备访问权限时，准备用户可执行命令，明确尚未替用户完成烧录。

## 1. 写入前确认镜像、卡和已有数据

先确认最终镜像构建完成、路径/大小合理，存在构建证据；重要旧镜像和 SD 上项目应先备份。
烧录会覆盖整卡，包括旧模型、Notebook、网络配置和驱动安装状态；新镜像不会自动迁移这些内容。
每次插卡、换读卡器都重新执行：

```bash
lsblk -o NAME,PATH,SIZE,MODEL,RO,TYPE,FSTYPE,LABEL,MOUNTPOINTS
```

设备名会改变：本次内置读卡器为 `/dev/mmcblk0`，更换 USB 读卡器后为 `/dev/sdb`。
这些仅是案例；不要把主机 `/dev/sda`、`/dev/nvme0n1` 或过去设备名当成当前目标。
核对容量、型号、分区和 RO；存在系统挂载、交换分区或设备身份不明时先停止。
镜像必须写到整卡，如 `/dev/sdb`，不是 `/dev/sdb1` 或 `/dev/sdb2`。

## 2. 简单可靠的一次烧录

以下示例仅适用于已核实 `/dev/sdb` 就是 SD 卡的情况，按实际设备替换。
先关闭打开卡目录的文件管理器及终端，再卸载卡上所有已挂载分区：

```bash
sudo umount /dev/sdb1
sudo umount /dev/sdb2
lsblk -o NAME,SIZE,RO,MOUNTPOINTS /dev/sdb
```

“not mounted”无需修复；“busy”或卸载失败必须处理后再写。不要用 `|| true` 隐藏真实失败。
分区多于两个时全部核对卸载，不要只处理本例的 p1/p2。

```bash
image=/绝对路径/目标板卡-4.0.0.img
sudo dd if="$image" of=/dev/sdb bs=4M status=progress conv=fsync
sync
sudo blockdev --flushbufs /dev/sdb
sudo cmp -n "$(stat -c %s "$image")" "$image" /dev/sdb
echo $?
```

逐条执行，`dd`、刷新或读取报错时停止，不继续用后续命令掩盖失败。
`cmp` 无输出且退出码 0 表示本次读取的整个镜像长度一致；卡多余容量不参与比较。
默认写完立即校验，不重插、不挂载、不先启动板卡，减少自动挂载造成的差异。
取得 `cmp=0` 后安全拔卡，在板卡断电状态插入，按该板资料设置 SD 启动，再上电。
如果读卡器明确不支持 flush 操作，保留输出并按实际能力处理，不伪造成功。

## 3. 只有需要时控制桌面自动挂载

若 GNOME 桌面已经自动挂载卡，或此前 `cmp` 被挂载元数据干扰，可先临时关闭：

```bash
# 在普通桌面用户终端执行，不使用 sudo gsettings。
saved_automount=$(gsettings get org.gnome.desktop.media-handling automount)
saved_open=$(gsettings get org.gnome.desktop.media-handling automount-open)
gsettings set org.gnome.desktop.media-handling automount false
gsettings set org.gnome.desktop.media-handling automount-open false
```

这不是卸载命令；仍需卸载现有分区。核对设置读回为 false，并避免手动打开卡目录。
完成写入及 `cmp=0` 后先物理取卡，再恢复保存的原值：

```bash
gsettings set org.gnome.desktop.media-handling automount "$saved_automount"
gsettings set org.gnome.desktop.media-handling automount-open "$saved_open"
```

这是 GNOME 用户设置，不保证阻止其他用户、其他桌面或手动挂载。
若设置失败，明确说明；不要声称已关闭。异常退出时应给恢复方法，不把卡仍插着时自动挂载回来。
无需把每次正常烧录都变成自动挂载审计，也不强制安装额外写卡软件。

## 4. `cmp` 不同：先分清修改与损坏

`cmp` 默认只报第一处差异；一处落在元数据并不代表后面没有文件损坏。
Linux 桌面读写挂载会改变 ext4 超级块、访问时间、inode checksum 和 journal；启动后还会写日志/扩容。
因此首次开机后的整卡比较不同，不能直接判断烧录失败。
本次镜像 root 分区起点为 109051904 字节；该数值不得固定套在其他镜像。
案例 `differ: byte 109052973` 为一基位置，定位公式：

```text
109052973 - 1 - 109051904 - 1024 = 44
```

超级块偏移 44 是 `s_mtime` 挂载时间；不是 systemd 文件开头，也不是 DDR 地址。
只有全长度检查确认其余字节后，才可把限定差异解释成挂载行为；不可直接跳过整个 journal。

可选只读工具位于 skill 的 `scripts/compare_sd_image.py`：

```bash
sudo python3 /本技能绝对路径/scripts/compare_sd_image.py "$image" /dev/sdb
# 只有存在 inode/journal 差异时，再选择详细分类：
sudo python3 /本技能绝对路径/scripts/compare_sd_image.py "$image" /dev/sdb --details
```

工具要求目标及分区未挂载，不挂载、不修复、不写目标；支持范围以脚本 `--help` 为准。

| 退出码 | 含义 |
| --- | --- |
| 0 | 镜像长度内逐字节一致 |
| 3 | 仅限定超级块挂载字段及有效 checksum 变化；不是精确一致 |
| 4 | 详细模式识别为有效 inode atime/checksum 与 journal 位置的差异；不是精确一致 |
| 1 | 未解释差异、无效校验、读取失败或不支持布局；不能按正常挂载放行 |

详细模式核对完整 inode CRC，未知字段不放宽；几何或特性不支持时保守拒绝。
journal 分类仅说明块位置，不能证明交易内容正确；文件数据改变也可能通过文件系统结构检查。
如需检查结构，在未挂载的实际 root 分区执行一次：

```bash
sudo e2fsck -fn /dev/sdb2
echo $?
```

`-n` 禁止修复；不要擅自改成 `-y`、`-p`。退出 0 不等于全部文件 payload 与镜像一致。
已完整解释为限定元数据差异、结构检查为 0 后，可以上板试启动，不要求用户无限重复检查/重刷。
若仍有未知数据差异或 I/O 错误，保留结果再定位；不能仅凭 fsck 正常就忽略它们。

## 5. 本次故障的判断顺序

| 现象 | 下一步 |
| --- | --- |
| `dd: Read-only file system` | 检查 RO、SD 转接卡 LOCK、读卡器；设备未明确前不写 |
| SD `error -22`、sector 0 I/O error | 检查连接/重插、换读卡器或卡，观察内核日志；不先改设备树 |
| `invalid ELF header` 后 `Attempted to kill init` | 比较原 img 与卡上 init/systemd 库，先区分文件内容损坏与板端读取 |
| 原 img 文件正常、SD 库 SHA 不同且被识别为 data | 先重写并立即验证；尚不能只凭此确定卡片、读卡器或板端是哪一项造成 |
| 写后精确一致、上板仍相同 panic | 保留卡内容/完整串口，查板端 SD、供电及 XSA DDR 初始化，不反复重刷掩盖证据 |
| `regulatory.db` 缺失 warning | 属于无线监管数据库；不能作为 init ELF/panic 的原因 |

## 6. 串口完全无文字

Windows 能打开 COM、CP2104 枚举成功，只证明 USB 串口芯片可访问，不证明 SoC 已启动或主电源正常。
先通过拔插找到对应 COM，设置 115200、8 数据位、1 停止位、无校验、无流控。
先打开串口终端，再让板卡冷上电；检查外部电源与指示灯、正确 UART 接口及 SD 启动设置。
RKZU15EG 本次新旧 XSA 均为 UART0 MIO42–43，UART1 关闭；最终 stdout 为 `serial0:115200n8`。
MyZU7 或其他板卡的 UART MIO 可能不同；不能把 RK 参数视作所有 ZynqMP 通用参数。
没有核实厂商电压、极性和拨码表时，不猜 5 V/12 V、不猜 SW 编号或 ON/OFF 组合。
FSBL 默认不一定打印调试信息；完全收不到后续 U-Boot 时，不能直接归因 Linux 驱动。
已经可靠重刷一次并取得 `cmp=0`，串口仍全静默时转查启动链、连接和硬件，不要求继续反复刷卡。
