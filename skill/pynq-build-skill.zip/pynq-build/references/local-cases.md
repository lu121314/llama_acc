# 本机案例与文件索引

本节是截至 2026-11-02 的对话与文件快照，用于继续原项目或对照问题。操作前重新确认文件和设备；不要把这些板级配置、IP、设备名或哈希移植成所有板卡的默认值。

## 仓库与构建入口

- 主机仓库 `/mnt/data/PYNQ`，Docker 映射为 `/workspace`；日志通常在主机 `sdbuild/`。
- 本例 PYNQ 4.0 使用 AMD EDF `amd-edf-rel-v25.11.1`，Vivado/Vitis 2025.2；不能单由主机装了哪个版本推定实际使用的版本。
- MyZU7 板卡配置：`/mnt/data/PYNQ/boards/MyZU7/`；旧准备脚本：`work/myzu7-review/`。
- RKZU15EG 当前配置：`/mnt/data/PYNQ/boards/RKZU15EG/`。
- RK 的旧构建入口：`/mnt/data/PYNQ/work/rkzu15eg-review/build-rkzu15eg.sh`，接受 `--resume`；实际语义以脚本及当前 hooks 为准。
- RK foundation-r2 构建入口：`/mnt/data/PYNQ/work/rkzu15eg-foundation-r2-review/build-foundation-r2.sh`，不接受参数；先运行 `preflight.py`，再调用旧 wrapper。当前 r2 hook 仍会清理指定 boot 配方，不能保证从精确失败点继续。
- r2 原始包副本：`/mnt/data/PYNQ/work/rkzu15eg-foundation-r2-review/package/`。原用户包位于 `/mnt/data/RKZU15EG_PYNQ4_FOUNDATION_DP_PL_20261019_r2/` 下同名子目录。

## 镜像归属

| 板卡 | 镜像绝对路径 | 字节数 | 构建/验证情况 |
|---|---|---:|---|
| MyZU7 / ZU7CG | `/mnt/data/PYNQ/sdbuild/output/MyZU7-4.0.0.img` | 8265924608 | 2026-10-12 生成；对话中曾启动并检索无线热点 |
| RKZU15EG foundation DP/PL r2 | `/mnt/data/PYNQ/sdbuild/output/RKZU15EG-4.0.0.img` | 8433696768 | 2026-10-19 生成，最终静态检查通过；后续用户报告上电串口无输出，尚无本次成功登录证据 |

MyZU7 镜像 SHA256：

```text
9c6bf88086ebd9a03f306f56105739e05524e9b7a5ca8d9c5e837b2cf474d903
```

RK foundation-r2 镜像 SHA256：

```text
eee323b245bf017497bf81ad0f75d4bf3bf78cb2d2363debe153fe6bd684771e
```

MyZU7 备份在 `/mnt/data/PYNQ/backups/MyZU7-4.0.0-20261013-221421/`，含镜像、配置/XSA、boot 文件、驱动和 SHA256SUMS。旧 RK 备份目录为 `/mnt/data/PYNQ/backups/RKZU15EG-before-rebuild-20261019-144342/`；它与当前 foundation-r2 镜像不是同一次构建。

## 无线驱动包不能混用

本例三个包都显示内核 `6.12.40-xilinx-g0900176227cc`，但其构建配置与符号表不同。

| 包路径（均在 `/mnt/data/PYNQ/outputs/`） | 对应镜像 | 验证边界 |
|---|---|---|
| `aic8800-pynq4-6.12.40.tar.gz` | 原 MyZU7 | 曾出现 wlan0 并扫描到 2.4 GHz 热点；旧安装器未检查完整符号表，不能据此用于其他同版本内核 |
| `aic8800-rkzu15eg-usbhost-6.12.40.tar.gz` | 10 月 14 日 RK USB-host 镜像 | 用户曾实测 `a69c:88dc`、模块加载、wlan0、热点 111 DHCP 成功 |
| `aic8800-rkzu15eg-foundation-r2-6.12.40.tar.gz` | 当前 RK foundation-r2 | 11 月 1 日重新编译、MODPOST/架构/vermagic/导出符号检查通过；尚未在此镜像上板加载实测 |

旧 USB-host 包对应 Module.symvers SHA256：

```text
39f62c10b9307c72fdb4cc21a4c69b32f81af9ea3b72145a24ef58cdf122eae5
```

foundation-r2 包对应 Module.symvers SHA256：

```text
99cb732ff557462f342f26b641bce892da7fd3fac9b062818479d8fb51d4c5b3
```

foundation-r2 包归档 SHA256：`8a05bb9c656c3c8541afe121d3ddf19fc404a886287a2f6119124190a218b5f6`。来源、配置差异和编译记录在解包目录的 `BUILD-INFO.json` 与 `build-evidence/`。

原厂源码包缓存：`/mnt/data/PYNQ/work/aic8800-port/source/aic8800_linux_driver_2024_0510/aic8800fdrvpackage_2024_0510.deb`。原厂 deb 并非匹配所有 PYNQ 的通用成品内核模块。

## SD 与串口故障的实测结论

- 历史设备名从内置读卡器 `/dev/mmcblk0` 变为 USB 读卡器 `/dev/sdb`，同卡约 29.5 GiB。具体容量为 31666995200 字节；这不是以后自动选择 `/dev/sdb` 的授权或依据。
- 内置读卡器出现 `error -22 whilst initialising SD card`、`tuning execution failed`，随后第 0 扇区读取 I/O error、无法读取分区表；换 USB 读卡器后重新读出两分区。此证据支持读卡链路排查，不能直接宣判卡永久损坏。
- r2 首次 `cmp` 的 byte 109052973：减一得到零基地址，再减第二分区偏移 109051904 与超级块偏移 1024，得到 44，即 `s_mtime`。仅凭这一位置不能放行其他差异。
- 详细扫描最终找到超级块外 17 个窗口、6147 个差异字节：6037 位于内部 journal，其余仅 inode atime/额外时间位及对应 CRC；所有未知差异计数 0，相关 inode CRC 有效，其他镜像长度字节一致。
- 用户 `e2fsck -fn /dev/mmcblk0p2` 完成五轮且返回 0，因此建议上板试启动；没有把该结果表述成 journal 事务验证或位级完全一致。
- 主机曾识别 CP2104，USB ID `10c4:ea60`，Linux 设备 `/dev/ttyUSB0`；Windows 的 COM 号另行核对。RK 当前与旧版均为 UART0 / MIO42–43 / 115200，不能据 COM 可打开推断 PS 已启动。
- 用户最终改为要求给 MyZU7 烧录命令，偏好原始 `dd`，而非专用重刷脚本。对话没有确认这次 MyZU7 烧录完成或上板成功；不要补写不存在的结果。

## 进一步证据与已有教程

- RK 最终构建静态报告：`/mnt/data/PYNQ/sdbuild/output/boot/RKZU15EG/foundation-final-build/report.json`。
- boot 文件 SHA 清单：`/mnt/data/PYNQ/sdbuild/output/boot/RKZU15EG/SHA256SUMS.txt`；镜像内部 FAT 四个启动文件曾与其核对匹配。
- r2 集成问题记录：`/mnt/data/PYNQ/work/rkzu15eg-foundation-r2-review/README.md`；包含实际 Lopper/内核配置/打包校验修复，不应把所有本地补丁无条件用于新板卡。
- SD 诊断记录与原脚本：`/mnt/data/PYNQ/work/rkzu15eg-flash-foundation-r2-review/`。其中 `reflash-sdb.sh` 硬绑定当时的设备、容量和 **RK** 镜像，不能用于 MyZU7 或随意更换的卡。
- 通用移植教程：`/mnt/data/PYNQ/outputs/pynq4-board-porting-tutorial/README.md`；MyZU7 旧案例：`outputs/myzu7-pynq4-tutorial/README.md`。
- 无线联网教程及交互脚本：`/mnt/data/PYNQ/outputs/rkzu15eg-wifi-guide/`。其旧教程归档含 10 月 15 日 USB-host 驱动，安装部分需按目标镜像换成正确包。
- 板卡历史有线地址 `192.168.2.99`、用户名 `xilinx`，RK 热点连接曾获 `192.168.43.109`。均需板端 `ip -4 -br addr` 核实，不能预设另一块板或另一张卡继续使用。
